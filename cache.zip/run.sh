#!/bin/bash

./node_modules/.bin/gulp clean
./node_modules/.bin/gulp

